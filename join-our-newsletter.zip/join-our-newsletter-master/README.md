# Ejercicio 1 : Newsletter

---

- Nombre:
- Número de Control:

---

## 📌 Descripción
(Escribe aquí en qué consiste tu proyecto de forma breve)

---

## 🚀 Tecnologías utilizadas
- HTML  
- CSS  
- Otro: 

---

## 🔗 Enlace al proyecto
Repositorio en GitHub: [Pega aquí tu enlace]  
Deploy: [Pega aquí el deploy de GitHub Pages]
---

## 📝 Reflexión
(Escribe aquí unas líneas sobre lo que aprendiste, las dificultades que tuviste y cómo las solucionaste)
